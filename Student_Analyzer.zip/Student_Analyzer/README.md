# Student Marks Analyzer

## Setup
1. Create MySQL DB `student_db`
2. Edit `db.py` for credentials
3. Run app: `python main.py`

## Features
- Add students
- View + analyze marks
- Export to CSV
- REST API
- PyTest for API