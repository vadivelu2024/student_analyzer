
from flask import Flask, render_template, request, jsonify, send_file
from models.student_manager import Student, StudentManager
from utils.analyzer import analyze_marks
from utils.analyzer import analyze_marks, analyze_data

from utils.export import export_to_csv
import pandas as pd
import os

app = Flask(__name__)
manager = StudentManager()

@app.route('/')
def index():
    students = manager.get_students()
    summary = analyze_marks(students)
    return render_template('index.html', students=students, summary=summary)

@app.route('/add', methods=['GET', 'POST'])
def add():
    if request.method == 'POST':
        name = request.form['name']
        subject = request.form['subject']
        mark = int(request.form['mark'])
        manager.add_student(Student(name, subject, mark))
        return 'Student added!'
    return render_template('add.html')

@app.route('/export')
def export_data():
    # Ensure exports/ directory exists
    os.makedirs('exports', exist_ok=True)

    students = manager.get_students()
    df = pd.DataFrame(students, columns=['ID', 'Name', 'Subject', 'Mark'])

    csv_path = 'exports/students.csv'
    df.to_csv(csv_path, index=False)

    # Now call analysis
    analyze_data(csv_path)

    return send_file(csv_path, as_attachment=True)
@app.route('/api/students')
def api_students():
    students = manager.get_students()
    return jsonify(students)

@app.route('/report')
def report():
    return render_template('report.html', image_path='exports/subject_avg_plot.png')

if __name__ == '__main__':
    app.run(debug=True)
