# from app.db import get_db_connection
from db import get_db_connection

class Student:
    def __init__(self, name, subject, mark):
        self.name = name
        self.subject = subject
        self.mark = mark

class StudentManager:
    def __init__(self):
        self.conn = get_db_connection()
        self.cursor = self.conn.cursor()
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS students (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100),
                subject VARCHAR(100),
                mark INT
            )
        """)
        self.conn.commit()

    def add_student(self, student):
        self.cursor.execute(
            "INSERT INTO students (name, subject, mark) VALUES (%s, %s, %s)",
            (student.name, student.subject, student.mark)
        )
        self.conn.commit()

    def get_students(self):
        self.cursor.execute("SELECT * FROM students")
        return self.cursor.fetchall()