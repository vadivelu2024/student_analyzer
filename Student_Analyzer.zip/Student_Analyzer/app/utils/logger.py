import logging

logging.basicConfig(filename='logs/app.log', level=logging.INFO)

def log(message):
    logging.info(message)
