import csv

def export_to_csv(data):
    with open('students.csv', 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['ID', 'Name', 'Subject', 'Mark'])
        for row in data:
            writer.writerow(row)