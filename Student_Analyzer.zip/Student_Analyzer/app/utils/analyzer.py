import pandas as pd
import matplotlib.pyplot as plt
import os

def analyze_marks(data):
    df = pd.DataFrame(data, columns=['id', 'name', 'subject', 'mark'])
    summary = {
        'average': df['mark'].mean(),
        'highest': df['mark'].max(),
        'lowest': df['mark'].min()
        
    }
    return summary

# ✅ This function is needed in main.py
def analyze_data(csv_path):
    df = pd.read_csv(csv_path)

    # Group by subject and calculate average mark
    subject_avg = df.groupby('Subject')['Mark'].mean()

    # Create export directory if not exists
    os.makedirs('exports', exist_ok=True)

    # Plot average marks by subject
    plt.figure(figsize=(8, 5))
    subject_avg.plot(kind='bar', color='skyblue')
    plt.title("Average Marks per Subject")
    plt.xlabel("Subject")
    plt.ylabel("Average Mark")
    plt.tight_layout()
    plot_path = os.path.join('static', 'exports', 'subject_avg_plot.png')
    plt.savefig(plot_path)
    plt.close()
