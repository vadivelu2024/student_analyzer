import requests

def test_api_students():
    res = requests.get("http://127.0.0.1:5000/api/students")
    assert res.status_code == 200
    assert isinstance(res.json(), list)